#!/bin/bash

apache2-foreground

tail -f /dev/null
