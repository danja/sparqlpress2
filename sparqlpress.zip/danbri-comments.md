


Create a sparqlpress2 backend inside a blog
...
And populate it from commandline for now
----
I wonder if php has good enough rdfa+microdata +jsonld to parse out schema markup easily
----
Like does arc2 do named graphs, for example?
----
The number of wordpress sites publishing schemaorg using Yoast add-on is supposedly 10 million plus

So if some % of those were also interested to see what their own, or maybe a few, schema.org datasets looked like "as a knowledge graph", there could be some audience out there that we didn't really have in 2008

Dan sent Today at 15:17
Vast majority of the sites won't be at all technical
