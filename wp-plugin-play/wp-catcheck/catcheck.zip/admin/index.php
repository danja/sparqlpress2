<?php
echo 'Index';
?>