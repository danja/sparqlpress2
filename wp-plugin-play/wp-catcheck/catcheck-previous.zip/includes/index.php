
<?php // Silence is golden
echo 'Index';

        

        ?>
